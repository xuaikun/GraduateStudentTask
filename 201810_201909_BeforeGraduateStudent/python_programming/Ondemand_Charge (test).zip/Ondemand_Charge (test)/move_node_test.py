# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import TourConstructionProblem as T
Et = 1000 
for El in range(0, Et, 100):
     print "El =", El