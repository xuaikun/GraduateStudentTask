﻿# 对按周期性充电程序的解释
### 运行环境: python2.7 可以安装Anaconda，用自带的spyder运行或者重新安装pycharm运行

### 运行TourConstructionProblem.py 即可获取构建子回路的结果

### A_Star_Algorithm.py 实现A星算法

### JudgingWhetherSchedule.py 判断回路是否可调度

### test.py 用于数据测试